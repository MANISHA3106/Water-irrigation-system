async function main() {
    const [deployer] = await ethers.getSigners();
    const WaterIrrigationSystem = await ethers.getContractFactory("WaterIrrigationSystem");
    const contract = await WaterIrrigationSystem.deploy();
    console.log("Water Irrigation System deployed to:", contract.target);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
