import React, { useState } from 'react';
import '../styling/ReqWater.css';
import { isSlotAvailable, requestWater } from '../connection';
import { useNavigate } from 'react-router-dom';

const CustomForm = () => {
    const [fromHour, setFromHour] = useState('');
    const navigate = useNavigate(); 


    const [toHour, setToHour] = useState('');
    const [selectedDate, setSelectedDate] = useState('');
    const value = 500000;
    const handleFromHourChange = (event) => {
        const hour = parseInt(event.target.value);
        setFromHour(hour);
    };

    const handleToHourChange = (event) => {
        const hour = parseInt(event.target.value);
        setToHour(hour);
    };

    const handleDateChange = (event) => {
        setSelectedDate(event.target.value);
    };

    const handleSubmit = async () => {
        const result = await isSlotAvailable(localStorage.getItem('farmid'), fromHour, toHour, selectedDate);
        if (result) {
            requestWater(localStorage.getItem('farmaddress'), localStorage.getItem('farmid'), fromHour, toHour, selectedDate,value);
            alert('Request Send');
            navigate(-1);
        }
        else {
            alert('Sorry! Sort not available.')
        }

    };

    return (
        <div className='flexbox'>
            <div className="custom-form">
                <h2>Select Duration</h2>
                <label className='label'>Date:</label>
                <input type="date" className="custom-input" value={selectedDate} onChange={handleDateChange} />
                <label className='label'>From Hour:</label>
                <input type="number" className="custom-input" placeholder="Select 0-24" value={fromHour} onChange={handleFromHourChange} min={0} max={24} />
                <label className='label'>To Hour:</label>
                <input type="number" className="custom-input" placeholder="Select 0-24" value={toHour} onChange={handleToHourChange} min={0} max={24} />
                <button disabled={toHour <= fromHour || toHour > 24 || fromHour < 0 || toHour < 0} onClick={handleSubmit}>Submit</button>
            </div>
        </div>
    );
};

export default CustomForm;
