import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styling/Landingpage.css';
import { loginFarm } from '../connection';

const LandingPage = () => {
    const [farmerAddress, setFarmerAddress] = useState('');
    const [farmId, setFarmId] = useState('');
    const navigate = useNavigate(); 

    const loginHandler = async () => {
        try {
            await loginFarm(farmerAddress, farmId);
            localStorage.setItem('farmid',farmId);
            localStorage.setItem('farmaddress',farmerAddress)
            navigate('/farmer-view'); 
        } catch (error) {
            console.error('Error logging in:', error);
        }
    };

    const handleFarmerAddressChange = (event) => {
        setFarmerAddress(event.target.value);
    };

    const handleFarmIdChange = (event) => {
        setFarmId(event.target.value);
    };

    return (
        <div className='flexbox'>
            <div className="container">
                <div className="box">
                    <p className="login">Log in</p>
                    <div className="input-container">
                        <input
                            type="text"
                            required="required"
                            value={farmerAddress}
                            onChange={handleFarmerAddressChange}
                        />
                        <span className="label">Farmer Address</span>
                    </div>
                    <div className="input-container">
                        <input
                            type="number"
                            required="required"
                            value={farmId}
                            onChange={handleFarmIdChange}
                            max={30}
                            min={1}
                        />
                        <span>Farm ID</span>
                    </div>
                    <button className="submit" onClick={loginHandler}>Enter</button>
                </div>
            </div>
        </div>
    );
};

export default LandingPage;
