import React, { useEffect, useState } from 'react';
import '../styling/farmerview.css';
import { useNavigate, Link } from 'react-router-dom'; 
import { getCanalByFarmId, getFarmsByCanalId } from '../connection';

const FarmerView = () => {
    const [canalId, setCanalId] = useState('');
    const [farmsData, setFarmsData] = useState([]);

    const navigate = useNavigate();

    const waterHandle = () => {
        navigate('/request-water');
    };

  

    useEffect(() => {
        const fetchCanalData = async () => {
            try {
                const canalData = await getCanalByFarmId(localStorage.getItem('farmid'));
                setCanalId(canalData.canalId.toString());
            } catch (error) {
                console.error('Error fetching canal data:', error);
            }
        };

        fetchCanalData();
    }, []);

    useEffect(() => {
        const fetchFarmData = async () => {
            try {
                
                const farmData = await getFarmsByCanalId(canalId);
                setFarmsData(farmData);

            } catch (error) {
                console.error('Error fetching farm data:', error);
            }
        };

        if (canalId !== '') {
            fetchFarmData();
        }
    }, [canalId]);


    return (
        <>
            <div className='nav'>
                <button onClick={waterHandle}>Request Water</button>
                <div className='canal'>
                    <h2 className='canaltext'>Canal id: {canalId}</h2>
                </div>
            </div>
            <div className='farmsBox'>
                {farmsData.map((item) => (
                    <div className="card" key={item.farmId}>
                        <div className="card-image">
                        {item.farmAddress !== "0x0000000000000000000000000000000000000000" && (
                    <Link to={`/farm-stats/${item.farmId.toString()}`}>
                        <button className='absolute'>View Stats</button>
                    </Link>
                )}
                        </div>
                        <div className="card-description">
                            <p className="text-title">Farm ID: {item.farmId.toString()}</p>
                            <p className="text-title">Address:<span className='small'>{item.farmAddress}</span> </p>
                        </div>
                    </div>
                ))}
            </div>
        </>
    );
};

export default FarmerView;
