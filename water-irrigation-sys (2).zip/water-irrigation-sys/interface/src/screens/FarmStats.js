import React, { useEffect, useState } from 'react';
import '../styling/FarmStats.css';
import { useParams } from 'react-router-dom';
import { getFarmStatsByFarmId } from '../connection';

const FarmStats = () => {
    const { farmId } = useParams();
    const [statsData, setStatsData] = useState([]);

    useEffect(() => {
        const fetchFarmStats = async () => {
            if (!farmId) {
                alert('Farm ID is null or undefined');
                return; 
            }
    
            try {
                const farmStats = await getFarmStatsByFarmId(farmId); 
                setStatsData(farmStats);
            } catch (error) {
                console.log('Error fetching Farm Stats:', error);
            }
        };
    
        fetchFarmStats();
    }, [farmId]);
    

    return (
        <div>
            <table className="custom-table">
                <thead>
                    <tr>
                        <th>Canal Id</th>
                        <th>Date</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Charges (wei)</th>
                        <th>Water Consumption (ml)</th>
                    </tr>
                </thead>
                <tbody>
                    {statsData.map((item, index) => (
                        <tr key={index}>
                            <td>{item.canalId.toString()}</td>
                            <td>{item.date}</td>
                            <td>{item.fromHour.toString()}</td>
                            <td>{item.toHour.toString()}</td>
                            <td>{item.waterConsumption.toString()*100}</td>
                            <td>{item.waterConsumption.toString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default FarmStats;
