import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import BrowserRouter and Route
import LandingPage from './screens/LandingPage';
import FarmerView from './screens/FarmerView';
import RequestWater from './screens/RequestWater';
import FarmStats from './screens/FarmStats';

function App() {
  return (
    <Router>
      <Routes> 
        <Route exact path="/" element={<LandingPage/>} /> 
        <Route path="/farmer-view" element={<FarmerView/>} />
        <Route path="/request-water" element={<RequestWater/>} />
        <Route path="/farm-stats/:farmId" element={<FarmStats/>} /> 
      </Routes>
    </Router>
  );
}

export default App;
