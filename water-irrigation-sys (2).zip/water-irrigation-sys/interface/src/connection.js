const { Web3 } = require('web3');
const web3 = new Web3('http://127.0.0.1:8545/');
const contractAbi = require('./WaterIrrigationSystem.json').abi;
const contractAddress = '0x5FbDB2315678afecb367f032d93F642f64180aa3';

const contract = new web3.eth.Contract(contractAbi, contractAddress);

export async function loginFarm(farmAddress, farmId) {
    try {
        const result = await contract.methods.login(farmAddress, farmId).send({ from: farmAddress, gas: 300000 });
        console.log('Farm logged in:', result);
        return result
    } catch (error) {
        console.error('Error logging in farm:', error);
    }
}

export async function requestWater(farmAddress, farmId, fromHour, toHour, date, value) {
    try {
        const result = await contract.methods.requestWater(farmId, fromHour, toHour, date).send({ from: farmAddress, value: value, gas: 900000 });
        console.log('Water request sent:', result);
        return result;
    } catch (error) {
        console.error('Error requesting water:', error);
    }
}

async function updateCanalCapacity(canalAddress, canalId, capacity) {
    try {
        const result = await contract.methods.updateCanalCapacity(canalId, capacity).send({ from: canalAddress, gas: 300000 });
        console.log('Canal capacity updated:', result);
    } catch (error) {
        console.error('Error updating canal capacity:', error);
    }
}

contract.events.FarmLoggedIn()
    ?.on('data', event => {
        console.log('Farm logged in:', event.returnValues);
    })
    ?.on('error', error => {
        console.error('Error capturing FarmLoggedIn event:', error);
    });

contract.events.StatsUpdated()
    ?.on('data', event => {
        console.log('Stats updated:', event.returnValues);
    })
    ?.on('error', error => {
        console.error('Error capturing StatsUpdated event:', error);
    });

contract.events.WaterRequested()
    ?.on('data', event => {
        console.log('Water requested:', event.returnValues);
    })
    ?.on('error', error => {
        console.error('Error capturing WaterRequested event:', error);
    });



export async function getFarmsByCanalId(canalId) {
    try {
        const result = await contract.methods.getFarmsByCanalId(canalId).call();
        console.log('Farms by canal ID:', result);
        return result;
    } catch (error) {
        console.error('Error getting farms by canal ID:', error);
    }
}

async function getFarmStatsByDate(date) {
    try {
        const result = await contract.methods.getfarmsStatsByDate(date).call();
        console.log('Farm stats by date:', result);
    } catch (error) {
        console.error('Error getting farm stats by date:', error);
    }
}

async function getFarmStatsByCanalId(canalId) {
    try {
        const result = await contract.methods.getFarmStatsByCanalId(canalId).call();
        console.log('Farm stats by canal ID:', result);
    } catch (error) {
        console.error('Error getting farm stats by canal ID:', error);
    }
}

export async function getFarmStatsByFarmId(farmId) {
    try {
        const result = await contract.methods.getFarmStatsByFarmId(farmId).call();
        console.log('Farm stats by farm ID:', result);
        return result;
    } catch (error) {
        console.error('Error getting farm stats by farm ID:', error);
    }
}

export async function isSlotAvailable(farmId, fromHour, toHour, date) {
    try {
        const result = await contract.methods.isSlotAvailable(farmId, fromHour, toHour, date).call();
        console.log('Is slot available:', result);
        return result
    } catch (error) {
        console.error('Error checking if slot is available:', error);
    }
}
export async function getCanalByFarmId(farmId) {
    try {

        const result = await contract.methods.getCanalByFarmId(farmId).call();
        console.log('Canal:', result);
        return result 
    } catch (error) {
        console.error('Error checking if slot is available:', error);
    }
}

function getCurrentDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    let month = currentDate.getMonth() + 1;
    let day = currentDate.getDate();

    month = month < 10 ? '0' + month : month;
    day = day < 10 ? '0' + day : day;

    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
}


const currentDate = getCurrentDate();
